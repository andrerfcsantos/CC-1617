Esta pasta contém o trabalho TP2 de Comunicações por Computador
realizado pelo grupo PL38, constituido pelos elementos André Santos (A61778),
Diogo Machado (A75399) e Rui Leite (A75551).

Esta directoria está organizada da seguinte forma:

Ficheiros:
    TP2.imn -> Topologia CORE usada para o teste do sistema

Sub-directorias:
    jars/ -> Contêm os ficheiros .jar que podem ser executados
             directamente para correr o ReverseProxy e os WebServers

    scripts/ -> Scripts usados para correr o cenário de teste conforme
                explicado no relatório.

    src/ -> Código fonte dos programas desenvolvidos




