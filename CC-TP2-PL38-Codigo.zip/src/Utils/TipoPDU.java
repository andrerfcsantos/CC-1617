package Utils;

import java.io.Serializable;

public enum TipoPDU implements Serializable{
    DISPONIVEL,PROB_REQUEST,PROB_REPLY, SERVER_CLOSE
}
