package ReverseProxy.MonitorUDP;

public enum PkgStatus {
    RECEIVED, LOST
}
