#!/bin/bash
wget http://10.0.13.10:80/CG.zip