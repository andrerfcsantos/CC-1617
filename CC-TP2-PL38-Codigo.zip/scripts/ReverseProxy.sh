#!/bin/bash
java -jar ~/git-repos/CC-1617/out/jars/ReverseProxy.jar


