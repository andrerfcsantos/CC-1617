#!/bin/bash

mini-httpd -d ~/tp2server/

java -jar ~/git-repos/CC-1617/out/jars/WebServer.jar 10.0.14.10

